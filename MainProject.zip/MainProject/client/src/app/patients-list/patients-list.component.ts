import { Component, OnInit, OnDestroy } from '@angular/core';
import { Router,ActivatedRoute } from '@angular/router';
import { PatientService } from '../patient.service';
import { PatientModel } from '../patients-profile/patient.model'

@Component({
  selector: 'app-patients-list',
  templateUrl: './patients-list.component.html',
  styleUrls: ['./patients-list.component.css']
})
export class PatientsListComponent implements OnInit 
{
  title:String = "PATIENT'S PROFILE"
  id;
  sub;

  constructor(private patientService: PatientService,private router: Router,private _Activatedroute:ActivatedRoute) { }

  patientItem = new PatientModel(null,null,null,null,null,null,null,null,null,null,null,null);

  ngOnInit(): void 
  {
    this.sub = this._Activatedroute.paramMap.subscribe((params)=>{
    this.id = params.get('id');
    console.log("id"+this.id);
    this.patientService.getpatients(this.id).subscribe((data)=>{
    this.patientItem = JSON.parse(JSON.stringify(data));//parsing the products//
    console.log(this.patientItem);
    });
  });
  }
  ngOnDestroy()
  {
    this.sub.unsubscribe();
  }
}


