import { Component, OnInit } from '@angular/core';
import {PatientModel} from '../patients-profile/patient.model';
import{PatientService} from '../patient.service';
import { Router } from '@angular/router'
import { AuthService } from '../auth.service';
@Component({
  selector: 'app-edit-delete-patient',
  templateUrl: './edit-delete-patient.component.html',
  styleUrls: ['./edit-delete-patient.component.css']
})
export class EditDeletePatientComponent implements OnInit {

  title:String = "EDIT/DELETE PATIENT'S DETAILS HERE!!!"

  patients:PatientModel[];

  constructor(private auth:AuthService,private patientService: PatientService,private router: Router) {}

  ngOnInit(): void 
  {
    this.patientService.getPatients().subscribe((data)=>{
    this.patients=JSON.parse(JSON.stringify(data)); 
    
    })
  }
  delete(id)
  {
  this.patientService.delete(id);
  alert("Successfully Deleted");
  this.router.navigate(['/profile']);
  }

}
