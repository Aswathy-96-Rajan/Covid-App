import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EditDeletePatientComponent } from './edit-delete-patient.component';

describe('EditDeletePatientComponent', () => {
  let component: EditDeletePatientComponent;
  let fixture: ComponentFixture<EditDeletePatientComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EditDeletePatientComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EditDeletePatientComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
