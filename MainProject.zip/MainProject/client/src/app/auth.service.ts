import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import { Router } from '@angular/router';
import * as jwt_decode from 'jwt-decode';
import { Subject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AuthService 
{

  constructor(private http:HttpClient,private router: Router)  {}

  registerUser(user)
  {
    return this.http.post("http://localhost:3000/api/register", {"user":user})
    .subscribe((data)=>{console.log("yay!")});
  }
  loginUser(user)
  {
    return this.http.post("http://localhost:3000/api/login",{"user":user})
  }
  loggedIn()
  {
    return !!localStorage.getItem('token')
  } 
  gettoken()
  {
    return localStorage.getItem('token')
  }
  logout()
  {
    localStorage.removeItem('token')
    this.router.navigate(['/'])
  }
  identifyUserRole()
  {
  let token=localStorage.getItem('token');

  if(!!token)
  {
    let decodedToken = jwt_decode(token);
    let userType=decodedToken['type'];
    console.log(decodedToken);
    console.log(decodedToken['subject']);
    if(userType=='admin')
    {
      console.log("Permitted")
      return true;
    }
    else
    {
      console.log("Permitted")
      return false;
    } 
  }
  else
  {
    return false;
  }

  }
}
