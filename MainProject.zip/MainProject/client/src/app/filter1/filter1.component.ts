import { Component, OnInit, OnDestroy } from '@angular/core';
import { Router,ActivatedRoute} from '@angular/router';
import { PatientService } from '../patient.service';
import { PatientModel } from '../patients-profile/patient.model'


@Component({
  selector: 'app-filter1',
  templateUrl: './filter1.component.html',
  styleUrls: ['./filter1.component.css']
})
export class Filter1Component implements OnInit 
{

  filter="";
  sub;

  constructor(private patientService: PatientService,private router: Router,private _Activatedroute:ActivatedRoute) { }

  patients=[];
  totalResults;
  ngOnInit(): void 
  {
    this.sub = this._Activatedroute.paramMap.subscribe((params)=>{
    this.filter = params.get('filter');
    this.patientService.filterPatients(this.filter)
    .subscribe((data)=>{
    this.patients = JSON.parse(JSON.stringify(data));
    this.totalResults=this.patients.length;
    });
  });
  }
}
