export class PatientModel{
    constructor
    (
        public hospital:String,
        public Name: String,
        public Image:String,
        public Age: Number,
        public Gender: String,
        public Address: String,
        public City: String,
        public District: String,
        public State: String,
        public Country: String,
        public PhoneNumber: Number,
        public Status: String
    )
    {}
}