import { Component, OnInit } from '@angular/core';
import {PatientModel} from './patient.model'
import{PatientService} from '../patient.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-patients-profile',
  templateUrl: './patients-profile.component.html',
  styleUrls: ['./patients-profile.component.css']
})
export class PatientsProfileComponent implements OnInit {

  title:String = "COVID PATIENTS IN TRIVANDRUM MEDICAL COLLEGE"

  patients:PatientModel[];
  // patients = []
  //  demo =
  // [{
  // "Name":"R.Rahul",
  // "Image":"https://pbs.twimg.com/media/DZotU1hW0AEDN5F.jpg",
  // "Age":"23",
  // "Gender":"Male",
  // "Address":"No.30-MG Road",
  // "City":"Palayam",
  // "District":"Trivandrum",
  // "State":"Kerala",
  // "Country":"India",
  // "Status":"Under Treatment"
  // }]
  constructor(private patientService: PatientService,private router: Router) {}

  ngOnInit(): void 
  {
    // this.patientService.getPatients()
      this.patientService.getPatients().subscribe((data)=>{
      this.patients=JSON.parse(JSON.stringify(data)); //to get out of json format//
      // console.log("pat n n ")
      console.log(this.patients)
    //   if(this.patients.length==0)
    // {
    //   this.patients=this.demo;        //static array assignment
    // }
    }) 
    
  }
    

  //   this.patientService.getPatients()
  //   .subscribe(res => this.patients = res,
  //     err =>console.log(err))

  // }



}
