import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule} from '@angular/forms';
import {HttpClientModule,HTTP_INTERCEPTORS} from '@angular/common/http';
// import {BrowserAnimationsModule} from '@angular/platform-browser/animations';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { RegisterComponent } from './register/register.component';
import { LoginComponent } from './login/login.component';
import { PatientsListComponent } from './patients-list/patients-list.component';
import { HomeComponent } from './home/home.component';
import { AuthService } from './auth.service';
import {AuthGuard} from './auth.guard';
import {TokenInterceptorService} from './token-interceptor.service';
import { PatientsProfileComponent } from './patients-profile/patients-profile.component';
import { AddPatientComponent } from './add-patient/add-patient.component';
import { EditDeletePatientComponent } from './edit-delete-patient/edit-delete-patient.component';
import { UpdatePatientComponent } from './update-patient/update-patient.component';
import { FilterPatientsComponent } from './filter-patients/filter-patients.component';
import { Filter1Component } from './filter1/filter1.component';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { MainComponent } from './main/main.component';

@NgModule({
  declarations: [
    AppComponent,
    RegisterComponent,
    LoginComponent,
    PatientsListComponent,
    HomeComponent,
    PatientsProfileComponent,
    AddPatientComponent,
    EditDeletePatientComponent,
    UpdatePatientComponent,
    FilterPatientsComponent,
    Filter1Component,
    HeaderComponent,
    FooterComponent,
    MainComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    AppRoutingModule,
    HttpClientModule
    // BrowserAnimationsModule
  ],
  providers: [AuthService,AuthGuard,
  {
    provide:HTTP_INTERCEPTORS,
    useClass:TokenInterceptorService,
    multi:true
  }],
  bootstrap: [AppComponent]
})
export class AppModule { }
