import { Component, OnInit } from '@angular/core';
import { Router,ActivatedRoute } from '@angular/router';
import { PatientService } from '../patient.service';
import { PatientModel } from '../patients-profile/patient.model'

@Component({
  selector: 'app-update-patient',
  templateUrl: './update-patient.component.html',
  styleUrls: ['./update-patient.component.css']
})
export class UpdatePatientComponent implements OnInit 
{

  title:String = "UPDATE PATIENT'S DETAILS HERE!!!"

  id;
  sub;

  constructor(private patientService: PatientService,private router: Router,private _Activatedroute:ActivatedRoute) {}

  patientItem = new PatientModel(null,null,null,null,null,null,null,null,null,null,null,null);

  ngOnInit(): void 
  {
    
      this.sub = this._Activatedroute.paramMap.subscribe((params)=>{
      this.id = params.get('id');
      console.log("id"+this.id);
      this.patientService.getpatients(this.id).subscribe((data)=>{
      this.patientItem = JSON.parse(JSON.stringify(data));
      console.log(this.patientItem);

      if(this.patientItem.Gender=='male')
      {
        document.getElementById('radiomale').setAttribute('checked','true');
      }
      else if(this.patientItem.Gender=='female')
      {
        document.getElementById('radiofemale').setAttribute('checked','true');
      }
      else 
      {
        document.getElementById('radioothers').setAttribute('checked','true');
      }

      if(this.patientItem.Status=="cured")
      {
        document.getElementById('radio1').setAttribute('checked','true');
      }
      else if(this.patientItem.Status=="undertreatment")
      {
        document.getElementById('radio2').setAttribute('checked','true');
      }
      else
      {
        document.getElementById('radio3').setAttribute('checked','true');
      }
    });
  });
  }
  ngOnDestroy()
  {
    this.sub.unsubscribe();
  }
  update()
  {
    if(document.getElementById('radiomale')['checked'])  
    {
    this.patientItem.Gender='male';
    }
   else if(document.getElementById('radiofemale')['checked'])
    {
    this.patientItem.Gender='female';
    }
    else
    {
      this.patientItem.Gender='others';
    }
    if(document.getElementById('radio1')['checked'])  
    {
    this.patientItem.Status='cured';
    }
    else if(document.getElementById('radio2')['checked'])  
    {
      this.patientItem.Status='undertreatment';
    }
    else
    {
      this.patientItem.Status='died';
    }
    this.patientService.update(this.patientItem);
    alert("Successfully Updated");
    this.router.navigate(['/profile']);
  }
}
