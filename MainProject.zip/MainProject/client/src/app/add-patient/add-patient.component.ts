import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { PatientService } from '../patient.service';
import { PatientModel } from '../patients-profile/patient.model';
import { AuthService } from '../auth.service';

@Component({
  selector: 'app-add-patient',
  templateUrl: './add-patient.component.html',
  styleUrls: ['./add-patient.component.css']
})
export class AddPatientComponent implements OnInit {

  title:String = "ADD A PATIENT HERE!!!"

  constructor(private auth:AuthService,private patientService: PatientService,private router: Router) {}
  patientItem = new PatientModel(null,null,null,null,null,null,null,null,null,null,null,null);

  ngOnInit(): void {}
  AddPatient()
  {
    if(document.getElementById('radiomale')['checked'])  
    {
    this.patientItem.Gender='male';
    }
   else if(document.getElementById('radiofemale')['checked'])
    {
    this.patientItem.Gender='female';
    }
    else
    {
      this.patientItem.Gender='others';
    }
    if(document.getElementById('radio1')['checked'])  
    {
    this.patientItem.Status='cured';
    }
    else if(document.getElementById('radio2')['checked'])  
    {
      this.patientItem.Status='undertreatment';
    }
    else
    {
      this.patientItem.Status='died';
    }
    this.patientService.newPatient(this.patientItem);
    alert("Successfully Added");
    this.router.navigate(['/profile']);
  }

}
