export class UserModel{
    constructor
    (
        public username:String,
        // public code:String,
        public phonenumber:Number,
        public email:String,
        public password:String,
        public type:string
    )
    {}
}