import { Component, OnInit } from '@angular/core';
import{UserModel} from '../register/register.model';
import{AuthService} from '../auth.service';
import { Router} from '@angular/router';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit 
{


  registerUserData=new UserModel(null,null,null,null,null);

  constructor( private auth : AuthService, private router: Router) { }

  ngOnInit(): void {}

  registerUser()
  {
    if(document.getElementById('radioNormal')['checked'])  
    {
    this.registerUserData.type='normal';
    }
   else
    {
    this.registerUserData.type='admin';
    }
    this.auth.registerUser(this.registerUserData)
    alert("Successfully Registered");
    this.router.navigate(['/login']);
  }

}
