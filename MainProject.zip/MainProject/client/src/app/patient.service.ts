import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class PatientService {

  constructor(private http:HttpClient) {}
  getPatients()
  {
    return this.http.get("http://localhost:3000/api/profile");
  }
  getpatients(id)
  {
    return this.http.post("http://localhost:3000/api/patient",{"id":id})
    
  }
  newPatient(item) 
  {
    return this.http.post("http://localhost:3000/api/insert",{"patient":item})
    .subscribe(data => {console.log(data)})
  }
  delete(id) 
  {
    return this.http.post("http://localhost:3000/api/edit",{"id":id})
    .subscribe(status=>{console.log(status)})
  }
  update(item)
  {
    return this.http.post("http://localhost:3000/api/update",{"patient":item})
    .subscribe((status)=>{
    console.log("Successfully Updated");
  });
  }
  filterPatients(filter) 
  {
    return this.http.post("http://localhost:3000/api/filterDetails",{"filter":filter});
  }
}
