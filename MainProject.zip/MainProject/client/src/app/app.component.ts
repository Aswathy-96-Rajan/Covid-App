import { Component } from '@angular/core';
// import{AuthService} from './auth.service';
// import { Router } from '@angular/router';
// import * as jwt_decode from 'jwt-decode';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'COVID APP';
  constructor() {}
  // logout()
  // {
  //   localStorage.removeItem('token')
  //   this.router.navigate(['/'])
  // }
//   identifyUserRole()
// {
//   let token=localStorage.getItem('token');
  
//   if(!!token)
//   {
//     let decodedToken = jwt_decode(token,{header:true});
//     let userType=decodedToken['type'];
//     console.log(decodedToken);
//     console.log(decodedToken['subject']);
//     if(userType=='admin')
//     {
//       console.log("Permitted")
//       return true;
//     }
//     else
//     {
//       console.log("Permitted")
//       return false;
//     } 
//   }
//   else
//   {
//     return false;
//   }
// }
}
