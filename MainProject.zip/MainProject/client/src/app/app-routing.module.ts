import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { PatientsListComponent } from './patients-list/patients-list.component';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { HomeComponent } from './home/home.component';
import {AuthGuard} from './auth.guard';
import { PatientsProfileComponent } from './patients-profile/patients-profile.component';
import { AddPatientComponent } from './add-patient/add-patient.component';
import { EditDeletePatientComponent } from './edit-delete-patient/edit-delete-patient.component';
import { UpdatePatientComponent } from './update-patient/update-patient.component';
import { FilterPatientsComponent } from './filter-patients/filter-patients.component';
import { Filter1Component } from './filter1/filter1.component';
import { MainComponent } from './main/main.component';

const routes: Routes = 
[
  {path:'',redirectTo:'/',pathMatch:'full'},
  {path:'',component:HomeComponent},
  {path:'register',component:RegisterComponent},
  {path:'login',component:LoginComponent},
  {path:'profile', component:PatientsProfileComponent},
  {path:'patient/:id',component:PatientsListComponent},
  {path:'add',component:AddPatientComponent,canActivate:[AuthGuard]},
  {path:'edit',component:EditDeletePatientComponent,canActivate:[AuthGuard]},
  {path:'update/:id',component:UpdatePatientComponent,canActivate:[AuthGuard]},
  {path:'filter',component:FilterPatientsComponent},
  {path:'undertreatmentfilter/:filter',component:Filter1Component},
  {path:'main',component:MainComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule {}
