import { Component, OnInit } from '@angular/core';
import{UserModel} from '../register/register.model';
import{AuthService} from '../auth.service';
import { Router} from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  loginUserData=new UserModel(null,null,null,null,null);

  constructor(private auth : AuthService,private router: Router) { }

  ngOnInit(): void {}

  loginUser()
  {
    this.auth.loginUser(this.loginUserData)
    .subscribe(
      (res:any) => {
      console.log(res)
      localStorage.setItem('token',res.token)
      alert("Login Successful")
      this.router.navigate(['/main']);
      },
    err => {console.log(err),
    alert("Invalid Credentials");}
    )
  }

}
