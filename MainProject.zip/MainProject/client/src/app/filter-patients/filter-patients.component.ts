import { Component, OnInit } from '@angular/core';
import {PatientModel} from '../patients-profile/patient.model'
import  {PatientService} from '../patient.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-filter-patients',
  templateUrl: './filter-patients.component.html',
  styleUrls: ['./filter-patients.component.css']
})
export class FilterPatientsComponent implements OnInit {

  title:String = "FILTER THE PATIENTS HERE!!!"

  patients:PatientModel[];

  constructor(private patientService: PatientService,private router: Router) { }

  ngOnInit(): void {}

}
