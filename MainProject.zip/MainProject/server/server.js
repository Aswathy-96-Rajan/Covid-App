//checking the server//

const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const jwt = require('jsonwebtoken');
const api = require('./routes/api');
const port = 3000;
const app = express(); //instance//

app.use(cors());
app.use(bodyParser.json());
app.use('/api',api);
app.get('/',(req,res)=>{
    res.send("Hai");
});
app.listen(port,function(){
    console.log("Server :"+port);
})