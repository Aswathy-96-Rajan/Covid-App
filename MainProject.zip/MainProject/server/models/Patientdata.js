const mongoose = require('mongoose'); //requiring mongoose//
mongoose.connect('mongodb://localhost:27017/PatientDb'); //teaching the address of db//
const Schema = mongoose.Schema; //storing schema in a constant//

var NewPatientSchema = new Schema({ //this is the schema//
    Name:String,
    Image:String,
    Age:Number,
    Gender:String,
    Address:String,
    City:String,
    District:String,
    State:String,
    Country:String,
    PhoneNumber:Number,
    Status:String
});

var Patientdata = mongoose.model('patient',NewPatientSchema) //storing the model in a variable//
module.exports = Patientdata; //exporting model//
