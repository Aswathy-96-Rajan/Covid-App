const mongoose = require('mongoose');
mongoose.connect('mongodb://localhost:27017/PatientDb');
const Schema = mongoose.Schema;
const userSchema = new Schema({
    username:String,
    // code:String,
    phonenumber:Number,
    email:String,
    password:String,
    type:String
});
module.exports = mongoose.model('user',userSchema);