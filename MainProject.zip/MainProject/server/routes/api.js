const express = require('express');
const jwt = require('jsonwebtoken');
const router = express.Router();
const multer = require('multer');
const mongoose = require('mongoose');
const User = require('../models/user');
const PatientData = require('../models/Patientdata');
const db = 'mongodb://localhost:27017/PatientDb';
mongoose.connect(db,function(err){
    if(err){
        console.log(+err);
    }else{
        console.log('Connected to MongoDB');
    }
});
router.get('/profile',function(req,res){ //showing list of patients route//
    res.header("Access-Control-Allow-Origin","*") 
    res.header('Access-Control-Allow-Methods:GET, POST, PATCH, PUT, DELETE,OPTIONS');
    PatientData.find() 
        .then(function(patients){ 
            res.send(patients); 
        });
});
router.post('/filterDetails',function(req,res){ //to filter patients//
    res.header("Access-Control-Allow-Origin","*") 
    res.header('Access-Control-Allow-Methods:GET, POST, PATCH, PUT, DELETE,OPTIONS');
    let filter=req.body.filter;
    PatientData.find({Status:filter}) 
       .then(function(patient){ 
           res.send(JSON.parse(JSON.stringify(patient))); 
       });
});
router.post('/patient',(req,res)=>{  //finding a single patient route//
    res.header("Access-Control-Allow-Origin","*");
    res.header('Access-Control-Allow-Methods:GET, POST, PATCH, PUT, DELETE,OPTIONS');
    const id = req.body.id;
    PatientData.findOne({_id:id})
    .then((patient)=>{
        res.send(JSON.parse(JSON.stringify(patient)));
    });
});
router.post('/insert',function(req,res){ //inserting a new patient route//
    res.header("Access-Control-Allow-Origin","*");
    res.header('Access-Control-Allow-Methods:GET, POST, PATCH, PUT, DELETE,OPTIONS');
    var patient = {
        hospital:req.body.patient.hospital,
        Name : req.body.patient.Name,
        Image : req.body.patient.Image,
        Age : req.body.patient.Age,
        Gender:req.body.patient.Gender, 
        Address:req.body.patient.Address,
        City:req.body.patient.City,
        District:req.body.patient.District,
        State:req.body.patient.State,
        Country:req.body.patient.Country,
        PhoneNumber:req.body.patient.PhoneNumber,
        Status:req.body.patient.Status   
        
    }
    var patient = new PatientData(patient);
    patient.save();
});
router.post('/edit',(req,res)=>{ //deleting a delete route//
    res.header("Access-Control-Allow-Origin","*");
    res.header('Access-Control-Allow-Methods:GET, POST, PATCH, PUT, DELETE,OPTIONS');
    const id = req.body.id;
    PatientData.deleteOne({_id:id})
    .then((patients)=>{
        res.send(patients);
    });
});
router.post('/update',(req,res)=>{ //update a patient route//
    res.header("Access-Control-Allow-Origin","*");
    res.header('Access-Control-Allow-Methods:GET, POST, PATCH, PUT, DELETE,OPTIONS');
    let patient = 
    {
    _id:req.body.patient['_id'],
    Name : req.body.patient['Name'],
    Image : req.body.patient['Image'],
    Age : req.body.patient['Age'],
    Gender:req.body.patient['Gender'], 
    Address:req.body.patient['Address'],
    City:req.body.patient['City'],
    District:req.body.patient['District'],
    State:req.body.patient['State'],
    Country:req.body.patient['Country'],
    PhoneNumber:req.body.patient['PhoneNumber'],
    Status:req.body.patient['Status'] 
    
    }
    PatientData.updateOne({_id:patient._id},
        {$set:
            {
                Name : patient.Name,
                Image : patient.Image,
                Age : patient.Age,
                Gender : patient.Gender, 
                Address : patient.Address,
                City : patient.City,
                District : patient.District,
                State : patient.State,
                Country : patient.Country,
                PhoneNumber:patient.PhoneNumber,
                Status : patient.Status
            }})
            .then((patients)=>{
                res.send("Successfully Updated");
});
});
router.post('/register',(req,res)=>{ //registering//
    res.header("Access-Control-Allow-Origin","*");
    res.header('Access-Control-Allow-Methods:GET, POST, PATCH, PUT, DELETE,OPTIONS');
    let userdata = 
    {
        username:req.body.user.username,
        phonenumber:req.body.user.phonenumber,
        email : req.body.user.email,
        password : req.body.user.password,
        type:req.body.user.type
    }
    let user = User(userdata)
            user.save((error,registeredUser)=>{
            if(error){
            console.log(error)
            }
            else{ 
            let payload = {subject:user._id}
            let token = jwt.sign(payload,'secretkey')
            res.status(200).send({token});
            }
    })
});
router.post('/login',(req,res)=>{  //login//
    res.header("Access-Control-Allow-Origin","*");
    res.header('Access-Control-Allow-Methods:GET, POST, PATCH, PUT, DELETE,OPTIONS');
    var userData ={email:req.body.user.email,password:req.body.user.password};
    User.findOne({email:userData.email,password:userData.password},(err,user)=>{
        if(err)
        {
            console.log(err)
        }
        else
        {
            if(!user)
            {
                res.send('Invalid Details')
            }
            else
            {
                let payload = {subject:user._id,type:user.type}
                let token = jwt.sign(payload,'secretkey')
                res.status(200).send({token});
            }
        }
    })
})
router.get('/',(req,res)=>{
    res.send("Hello");
})
module.exports = router;